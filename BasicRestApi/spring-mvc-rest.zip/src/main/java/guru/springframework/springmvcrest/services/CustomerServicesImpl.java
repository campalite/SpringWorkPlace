/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guru.springframework.springmvcrest.services;

import guru.springframework.springmvcrest.domain.Customer;
import java.util.List;
import guru.springframework.springmvcrest.respositories.CustomerRepository;
import org.springframework.stereotype.Service;

@Service
public class CustomerServicesImpl implements CustomerService{
    
    private final CustomerRepository customerRespository;

    public CustomerServicesImpl(CustomerRepository customerRespository) {
        this.customerRespository = customerRespository;
    }

    @Override
    public Customer findCustomerById(Long id) {
        return customerRespository.findById(id).get();
    }

    @Override
    public List<Customer> findAllCustomers() {
        return customerRespository.findAll();
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRespository.save(customer);
    }
    
}
