/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guru.springframework.springmvcrest.bootstrap;

import guru.springframework.springmvcrest.domain.Customer;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import guru.springframework.springmvcrest.respositories.CustomerRepository;


@Component
public class BootStrapData implements CommandLineRunner{

    private final CustomerRepository customerRespository;

    public BootStrapData(CustomerRepository customerRespository) {
        this.customerRespository = customerRespository;
    }
    
    @Override
    public void run(String... args) throws Exception {
        
        System.out.println("Loading customer data");
        
        Customer c1 = new Customer();
        c1.setFirstName("Michale");
        c1.setLastName("Weston");
        customerRespository.save(c1);
        
        Customer c2 = new Customer();
        c2.setFirstName("Sam");
        c2.setLastName("Axe");
        customerRespository.save(c2);
        
        Customer c3 = new Customer();
        c3.setFirstName("Fiona");
        c3.setLastName("Glennann");
        customerRespository.save(c3);
        System.out.println("Customer Saved: " + customerRespository.count());
    }
    
}
